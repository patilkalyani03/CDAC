//1.Declare a single-dimensional array of 5 integers inside the main method. Traverse the array to print the default 
//values. Then accept records from the user and print the updated values of the array.
package org.example_1;
import java.util.Scanner;
	

public class Program {
	public static void main(String[] args) {
		
		int[] arr = new int[5];
		
		System.out.println("Default values: ");
		for(int i = 0; i<arr.length; i++) {
			System.out.print(arr[i]+ " ");
		}
		
		Scanner sc = new Scanner(System.in);
		System.out.println("\nEnter the array values: ");
		for(int i = 0; i<arr.length; i++) {
			arr[i] = sc.nextInt();
		}
		
		System.out.println("Values are: ");
		for(int i = 0; i<arr.length; i++) {
			System.out.print(arr[i]+ " ");
		}
		sc.close();
	}

}

/*Output:
Default values: 
0 0 0 0 0 
Enter the array values: 
10
20
30
40
50
Values are: 
10 20 30 40 50 
*/