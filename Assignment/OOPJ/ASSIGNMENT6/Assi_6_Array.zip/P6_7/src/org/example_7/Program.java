//7.Declare a single-dimensional array as a field inside a class and instantiate it inside the class constructor. 
//Define methods named acceptRecord and printRecord within the class and test their functionality.

package org.example_7;
import java.util.Scanner;
public class Program {
	private int[] arr;
	Scanner sc = new Scanner(System.in);
	
	Program(){
		System.out.println("Enter the size: ");
        int size = sc.nextInt();  
        this.arr = new int[size];
	}
	
	public Program(int size) {
		this.arr = new int[size];
	}

	private void acceptRecord() {
		System.out.println("Enter the elements: ");
		for(int i=0; i<arr.length; i++) {
			arr[i] = sc.nextInt();
			
		}
	}
	
	private void printRecord() {
		for(int i=0; i<arr.length; i++) {
			System.out.println("arr["+i+"] = "+arr[i]);
		}
		
	}
	
	public static void main(String args[]) {
		
		Program d = new Program();
		d.acceptRecord();
		d.printRecord();
	}


}
