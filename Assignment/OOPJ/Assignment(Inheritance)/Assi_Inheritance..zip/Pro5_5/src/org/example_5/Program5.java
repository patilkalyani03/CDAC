package org.example_5;

class Vehicle {
	public void startEngine() {
		System.out.println(" Engine is starting");
	}

	public void stopEngine() {
		System.out.println(" Engine has stopped ");
	}
}

class Car extends Vehicle {
	@Override
	public void startEngine() {
		System.out.println(" Engine is starting in car");
	}

	@Override
	public void stopEngine() {
		System.out.println(" Engine has stopped in car ");
	}
}

class Motorcycle extends Vehicle {
	@Override
	public void startEngine() {
		System.out.println(" Engine is starting in motorcycle");
	}

	@Override
	public void stopEngine() {
		System.out.println(" engine has stopped in motorcycle ");
	}
}

public class Program5 {
	public static void main(String[] args) {
		Vehicle v = new Car();
		v.startEngine();
		v.stopEngine();
		v = new Motorcycle();
		v.startEngine();
		v.stopEngine();
		}

}
