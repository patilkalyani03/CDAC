package org.example_2;

public class Logger {
    private static Logger instance = null;
    private String logMessages;
   
    private Logger() {
        logMessages = "";
    }
    
    public static Logger getInstance() {
        if (instance == null) {
            instance = new Logger();
        }
        return instance;
    }
    
    public void log(String message) {
        logMessages += message + "\n";
    }
    
    public String getLog() {
        return logMessages;
    }
    
    public static void main(String[] args) {
        Logger logger = Logger.getInstance();
        
     
        logger.log("First log message");
        logger.log("Second log message");
        
      
        System.out.println("Log contents:");
        System.out.println(logger.getLog());
        
       
        Logger anotherLogger = Logger.getInstance();
        anotherLogger.log("Third log message");
       
        System.out.println("\nUpdated log contents:");
        System.out.println(logger.getLog());

	}
 
}